1. Extract files and navigate to correct directory.
2. Execute make command.
3. Type ./math_stuff to receive prompt.
4. Follow directions on prompt.